const express = require('express');
const router = express.Router();
const clienteController = require('./controller/controleClientes');
const telefoneController = require('./controller/controleTelefone');
const quartoController = require('./controller/carros');


//Routes Cliente
router.get('/clientes', clienteController.listarClientes);
router.post('/clientes', clienteController.criarCliente);
router.delete('/clientes/:id', clienteController.deletarCliente);
router.put('/clientes/:id', clienteController.atualizarCliente);


//Routes Telefone
router.post('/telefones', telefoneController.criarTelefone);
router.get('/cliente/:clienteId', telefoneController.listarTelefonesPorCliente);
router.get('/telefones', telefoneController.listarTelefones);
router.delete('/telefones/:id', telefoneController.deletarTelefone);

//Routes Carros

router.get('/carros', quartoController.listarQuartos);
router.post('/carros', quartoController.criarQuarto);
router.put('/carros/:id', quartoController.atualizarQuarto);
router.delete('/carros/:id', quartoController.deletarQuarto);

module.exports = router;