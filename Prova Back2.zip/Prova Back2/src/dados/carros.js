const connect = require('../connect/connect');

const getAllcarros = (callback) => {
    connect.query('SELECT * FROM telefone', (err, results) => {
        if (err) return callback(err, null);
        callback(null, results);
    });
};


const getcarroByClienteId = (clienteId, callback) => {
    connect.query('SELECT * FROM telefones WHERE cliente_id = ?', [clienteId], callback);
};

const createcarro = (data, callback) => {
    connect.query('INSERT INTO telefone SET ?', data, (err, results) => {
        if (err) return callback(err, null);
        callback(null, { id: results.insertId, ...data });  
    });
};

const updatecarro = (id, data, callback) => {
    connect.query('UPDATE telefones SET ? WHERE telefone_id = ?', [data, id], callback);
};

const deletecarro = (id, callback) => {
    connect.query('DELETE FROM telefone WHERE telefone_id = ?', [id], callback);
};

module.exports = {
    getAllcarros,
    getcarroByClienteId,
    createcarro,
    updatecarro,
    deletecarro
};
