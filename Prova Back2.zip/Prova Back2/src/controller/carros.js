const cliente = require('../dados/clienteModel');

exports.listarcarros = (req, res) => {
    carro.getAllCarros((err, results) => {
        if (err) return res.status(500).send({ message: 'Erro ao listar carros.' });
        res.status(200).send(results);
    });
};

exports.criarCarros = (req, res) => {
    const novoCarro = {
        marca_veiculo: req.body.marca_veiculo, 
        modelo_veiculo: req.body.modelo_veiculo, 
        ano_veiculo: req.body.ano_veiculo,
        fabricacao_veiuclo: req.body.fabricacao_veiuclo,
        cliente_id: req.body.cliente_id,
      };

    cliente.createCarro(novoCliente, (err, carro) => {
        if (err) return res.status(500).send({ message: 'Erro ao salvar carro.' });
        res.status(201).send(cliente);
    });
};

exports.atualizarCliente = (req, res) => {
    const { id } = req.params;
    const carroAtualizado = req.body;

    carro.updateCarro(id, carroAtualizado, (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: 'Carro atualizado com sucesso' });
    });
};

exports.deletarCarro = (req, res) => {
    const { id } = req.params;

    Carro.deleteCarro(id, (err) => {
        if (err) return res.status(500).json({ error: err.message });
        
        res.json({ message: 'Carro deletado com sucesso' });
    });
};
